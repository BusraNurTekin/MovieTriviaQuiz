package com.example.movietriviaquizapplication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Button;
import android.content.Intent;
import android.widget.Toast;

public class MovieTriviaQuiz extends Activity {
    static final int RESTART_EXAM = 1;
    private TextView question;
    private Button choice1;
    private Button choice2;
    private Button choice3;
    private Button choice4;
    private Button quit;
    private ArrayList<Question> questions;
    private int numberOfCorrectAnswers;
    private int questionNo;
    private int correctAnswer;

    private void readQuestionsFromFile(){
        InputStream stream = getResources().openRawResource(R.raw.question);
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, Charset.forName("UTF-8")));
        Question newQuestion;
        String question;
        questions = new ArrayList<Question>();
        try {
            while ((question = reader.readLine()) != null) {
                String[] questionContent = question.split(";");
                if ((questionContent[6].equalsIgnoreCase("A") || questionContent[6].equalsIgnoreCase("B") || questionContent[6].equalsIgnoreCase("C") || questionContent[6].equalsIgnoreCase("D"))){
                    newQuestion = new Question(questionContent[0], questionContent[1], questionContent[2], questionContent[3], questionContent[4], questionContent[5]);
                    questions.add(newQuestion);
                }
            }
        } catch (IOException e) {
        }
    }

    private Question getCurrentQuestion(){
          return null;
    }

    private void showCurrentQuestion(){
        Question currentQuestion;
        currentQuestion = getCurrentQuestion();
        if (currentQuestion != null){
            question.setText((questionNo + 1) + ") " + currentQuestion.getQuestion());
            choice1.setText("A) " + currentQuestion.getChoice1());
            choice2.setText("B) " + currentQuestion.getChoice2());
            choice3.setText("C) " + currentQuestion.getChoice3());
            choice4.setText("D) " + currentQuestion.getChoice4());
            if (currentQuestion.getCorrectAnswer().equalsIgnoreCase("A")){
                correctAnswer = 1;
            } else {
                if (currentQuestion.getCorrectAnswer().equalsIgnoreCase("B")){
                    correctAnswer = 2;
                } else {
                    if (currentQuestion.getCorrectAnswer().equalsIgnoreCase("C")){
                        correctAnswer = 3;
                    } else {
                        correctAnswer = 4;
                    }
                }
            }
        }
    }

    private void startExam(){
        questionNo = 0;
        numberOfCorrectAnswers = 0;
        Collections.shuffle(questions);
        showCurrentQuestion();
        choice1.setEnabled(true);
        choice2.setEnabled(true);
        choice3.setEnabled(true);
        choice4.setEnabled(true);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        question = (TextView) findViewById(R.id.question);
        question.setEnabled(false);
        choice1 = (Button) findViewById(R.id.choice1);
        choice2 = (Button) findViewById(R.id.choice2);
        choice3 = (Button) findViewById(R.id.choice3);
        choice4 = (Button) findViewById(R.id.choice4);
        quit = (Button)findViewById(R.id.quit);
        choice1.setOnClickListener(choiceClick);
        choice2.setOnClickListener(choiceClick);
        choice3.setOnClickListener(choiceClick);
        choice4.setOnClickListener(choiceClick);
        quit.setOnClickListener(quitClick);
        readQuestionsFromFile();
        startExam();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RESTART_EXAM) {
            if (resultCode == RESULT_OK) {
                startExam();
            }
        }
    }
    public OnClickListener choiceClick = new OnClickListener() {
        public void onClick(View v){
            if (((String)v.getTag()).equalsIgnoreCase(Integer.toString(correctAnswer))){
                numberOfCorrectAnswers++;
            }
            questionNo++;
                String message = "You answered " + numberOfCorrectAnswers + " questions correctly!";
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
                choice1.setEnabled(false);
                choice2.setEnabled(false);
                choice3.setEnabled(false);
                choice4.setEnabled(false);

        }
    };
    public OnClickListener quitClick = new OnClickListener() {
        public void onClick(View v){
            startExam();
            Intent subjectsIntent = new Intent(MovieTriviaQuiz.this, finishPage.class);
            startActivityForResult(subjectsIntent, RESTART_EXAM);
        }
    };

}
